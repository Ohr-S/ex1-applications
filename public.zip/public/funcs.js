(function () {
    document.addEventListener('DOMContentLoaded', function () {

        document.getElementById("example").addEventListener("click", example);
    }, false);

   function example(){
       alert("Button clicked");
   }

})();
